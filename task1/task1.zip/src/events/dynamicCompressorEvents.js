function setDynamicCompressorAttack(value) {
  compressorFilter.attack(value);
}

function setDynamicCompressorKnee(value) {
  compressorFilter.knee(value);
}

function setDynamicCompressorRelease(value) {
  compressorFilter.release(value);
}

function setDynamicCompressorRatio(value) {
  compressorFilter.ratio(value);
}

function setDynamicCompressorTreshold(value) {
  compressorFilter.threshold(value);
}

function setDynamicCompressorDryWet(value) {
  compressorFilter.drywet(value);
}

function setDynamicCompressorOutputLevel(value) {
  compressorFilter.amp(value);
}