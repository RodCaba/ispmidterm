function setDelayTime(time) {
  delayFilter.delayTime(time);
}

function setDelayFeedback(feedback) {
  delayFilter.feedback(feedback);
}

function setDelayDryWet(dryWet) {
  delayFilter.drywet(dryWet);
}

function setDelayOutputLevel(level) {
  delayFilter.amp(level);
}